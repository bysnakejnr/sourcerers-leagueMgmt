export function validateSchemaProperty(ctx, property) {
  return ([ctx].parameterId = property ? true : false);
}
